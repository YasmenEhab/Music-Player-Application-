/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediaplayer;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author Ammar
 */
public class MediaPlayer extends Application {
    
    private static Stage primarystage;
    
    @Override
    public void start(Stage primarystage) throws Exception {
        
        MediaPlayer.primarystage= primarystage;
        Parent root = FXMLLoader.load(getClass().getResource("StartScene.fxml"));
        Scene scene = new Scene(root);
        primarystage.setScene(scene);
        
        primarystage.setTitle("Media Player");
        
        primarystage.show();
        
        
        /*
        Parent root = FXMLLoader.load(getClass().getResource("MediaPlayer.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Media Player");
        
      
        
        
        
        stage.setScene(scene);
        stage.show();*/
    }
    
    public static void switchScene(String fxmlFile) throws Exception {
        Parent newRoot = FXMLLoader.load(MediaPlayer.class.getResource(fxmlFile));
        Scene newScene = new Scene(newRoot);
        primarystage.setScene(newScene);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}